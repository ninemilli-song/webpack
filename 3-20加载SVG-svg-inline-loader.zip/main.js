import svgContent from './svgs/alert.svg';

window.document.getElementById('app').innerHTML = svgContent;
